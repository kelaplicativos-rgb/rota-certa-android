package br.com.mapeiaia.rotacerta

import java.text.Normalizer
import java.util.Locale

object RideScreenTextClassifier {
    private val fareToken = String(byteArrayOf(0x52, 0x24), Charsets.UTF_8)
    private val fareTokenRegex = Regex.escape(fareToken)
    private val fareMatcher = Regex("BRL".replace("BRL", fareTokenRegex) + """\s*\d""", RegexOption.IGNORE_CASE)
    private val distanceRegex = Regex("""\b\d+(?:[,.]\d+)?\s*km\b""", RegexOption.IGNORE_CASE)
    private val routeStepRegex = Regex(
        """\b(?:\d{1,2}\s*h(?:\s*e)?\s*)?\d{1,3}\s*(?:min|minuto|minutos)\.?\s*(?:\(\s*(?:\d+(?:[,.]\d+)?\s*)?(?:m|km)\s*\))?""",
        RegexOption.IGNORE_CASE,
    )
    private val addressRegex = Regex(
        """(?:\b(?:rua|avenida|rodovia|estrada|travessa|alameda|praca|bairro|jardim|cidade|parque|vila|terminal|estacao|metro)\b|\b(?:r|av)\.)""",
        RegexOption.IGNORE_CASE,
    )
    private val mapAddressMarkerRegex = Regex(
        """(?m)^\s*[ab]\s+(?:(?:rua|avenida|rodovia|estrada|travessa|alameda|praca|bairro|jardim|cidade|parque|vila|terminal|estacao|metro)\b|\b(?:r|av)\.|[\wÀ-ÿ]+\s*,?\s*\d{1,5})""",
        RegexOption.IGNORE_CASE,
    )
    private val rideKeywords = listOf(
        "aceitar",
        "corrida",
        "corridas",
        "pedido de viagem",
        "pedidos de viagem",
        "viagem longa",
        "radar de viagens",
        "uber",
        "uberx",
        "dinheiro",
        "pix",
        "parada",
        "parada(s)",
        "ofereca sua tarifa",
        "negocia",
        "perfil premium",
        "perfil essencial",
        "pop expresso",
        "prioritario",
        "area de risco",
        "exclusivo",
        "verificado",
        "preco justo",
    )
    private val viewerShellKeywords = listOf(
        "editar",
        "pesquisar na imagem",
        "navegar para cima",
        "compartilhar",
        "adicionar a pasta",
        "com estrela",
        "mais opcoes",
        "galeria",
    )

    fun ignoreReason(text: String): String? {
        val normalized = text.normalizedForMatch()
        if (looksLikeRotaCertaDiagnostic(normalized)) {
            return "Diagnostico do Rota Certa detectado; nenhum card de chamada ativo."
        }
        if (looksLikeAndroidSystemShade(normalized)) {
            return "Tela do sistema/atalhos Android detectada; nenhum card de chamada ativo."
        }
        if (looksLikeNinetyNineSettingsMenu(normalized)) {
            return "Menu/configuracoes da 99 detectado; nenhum card de chamada ativo."
        }
        if (looksLikeUberIdleScreen(normalized)) {
            return "Tela inicial/offline/area de espera do Uber detectada; nenhum card de chamada ativo."
        }
        if (looksLikeNavigationScreen(normalized) && !hasRideEvidence(text)) {
            return "Navegador/GPS detectado sem card de chamada ativo."
        }

        val viewerHits = viewerShellKeywords.count { normalized.contains(it) }
        if (viewerHits >= 2 && !hasRideEvidence(text)) {
            return "Tela de visualizador/galeria detectada sem texto de card de corrida."
        }

        return null
    }

    fun shouldIgnore(text: String): Boolean = ignoreReason(text) != null

    fun looksLikeRideCard(text: String): Boolean {
        if (shouldIgnore(text)) return false
        return hasRideEvidence(text)
    }

    private fun hasRideEvidence(text: String): Boolean {
        val normalized = text.normalizedForMatch()
        val hasFareAmount = fareMatcher.containsMatchIn(text)
        val hasRideKeyword = rideKeywords.any { normalized.contains(it) }
        val hasRouteSignal = routeStepRegex.containsMatchIn(text) || distanceRegex.containsMatchIn(text)
        val hasAddressSignal = addressRegex.containsMatchIn(normalized) || mapAddressMarkerRegex.containsMatchIn(text)

        return hasRideKeyword && (hasRouteSignal || hasAddressSignal) ||
            hasFareAmount && hasRouteSignal && hasAddressSignal
    }

    private fun looksLikeRotaCertaDiagnostic(normalized: String): Boolean =
        normalized.contains("rota certa diagnostico") &&
            normalized.contains("texto lido") &&
            normalized.contains("pacote:")

    private fun looksLikeAndroidSystemShade(normalized: String): Boolean {
        val systemHits = listOf(
            "ativado",
            "desativado",
            "reducao de brilho extra",
            "editar atalhos",
            "killapps",
            "ccleaner",
            "baxa",
        ).count { normalized.contains(it) }
        return systemHits >= 2
    }

    private fun looksLikeNinetyNineSettingsMenu(normalized: String): Boolean {
        val menuHits = listOf(
            "configurar solicitacoes",
            "preferencias de servicos",
            "ferramentas de aceitacao",
            "definir meu destino",
            "status da solicitacao",
            "teste de status",
            "eventos futuros",
            "desconectar",
        ).count { normalized.contains(it) }
        val hasOfferAction = normalized.contains("selecionar") || normalized.contains("aceitar")
        return menuHits >= 3 && !hasOfferAction
    }

    private fun looksLikeUberIdleScreen(normalized: String): Boolean {
        val hasOfferAction = listOf("aceitar", "uberx", "viagem longa", "exclusivo").any { normalized.contains(it) }
        if (hasOfferAction) return false

        val hasOfflineSignal = normalized.contains("voce esta offline") ||
            normalized.contains("nao e possivel ficar offline")
        val hasWaitingAreaSignal = normalized.contains("area de espera") ||
            normalized.contains("motorista parceiro") ||
            normalized.contains("gru")
        val hasHomeSignals = listOf(
            "pagina inicial",
            "pesquisar locais",
            "recursos de seguranca",
            "tendencias de ganhos",
            "preferencias",
            "agenda de viagens",
            "ver tempo ao volante",
            "registro de viagens",
        ).count { normalized.contains(it) }
        val zeroFarePrefix = fareToken.lowercase(Locale.ROOT)
        val hasZeroEarnings = normalized.contains(zeroFarePrefix + " 0,00") ||
            normalized.contains(zeroFarePrefix + " 0.00")

        return hasOfflineSignal || (hasHomeSignals >= 3 && hasZeroEarnings) || (hasWaitingAreaSignal && hasZeroEarnings)
    }

    private fun looksLikeNavigationScreen(normalized: String): Boolean {
        val navigationHits = listOf(
            "iniciar",
            "visao geral",
            "pesquisar aqui",
            "pesquisar no mapa",
            "sua localizacao",
            "evitar pedagios",
            "recentralizar",
            "tempo restante",
            "chegada",
        ).count { normalized.contains(it) }
        val mapOnlyHits = listOf(
            "mapa",
            "satellite",
            "satelite",
            "camadas",
            "postos",
            "restaurantes",
        ).count { normalized.contains(it) }
        return navigationHits >= 2 || (navigationHits >= 1 && mapOnlyHits >= 2)
    }

    private fun String.normalizedForMatch(): String =
        Normalizer.normalize(lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("""\p{Mn}+"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
}

package br.com.mapeiaia.rotacerta

import org.junit.Assert.assertEquals
import org.junit.Test

class RideAppSpecificParserTest {
    @Test
    fun parsesNinetyNineTemplateLikeCardUsingPackage() {
        val text = """
            Dinheiro
            R$12,40
            4,97 409 corridas
            Perfil Essencial
            3min (462m)
            Comercial Esperanca, Avenida
            Sapopemba, 13309 - Jardim Aduto
            5min (1,9km)
            Rua Augustin Luberti, 1053, Fazenda
            da Juta
            Selecionar
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "com.app99.driver")

        assertEquals("99-card-template", result.parserName)
        assertEquals("Comercial Esperanca, Avenida Sapopemba, 13309 - Jardim Aduto", result.fields.pickup)
        assertEquals("Rua Augustin Luberti, 1053, Fazenda da Juta", result.fields.destination)
        assertEquals("R$12,40", result.fields.fare)
    }

    @Test
    fun parsesNinetyNineDiagnosticCardWithPromoBlockAndZeroBalance() {
        val text = """
            12:27 99
            APOPEMBA
            VANNI NASCO
            R$0,00
            Av. Afons de Sampaio e so
            M
            FAÇA UMA
            GRANA EXTRA
            Indicando um motora que
            parou de correr com a 99
            O 50,,ll 79
            Av. Aricanduva
            Carregando..
            Gorid eta
            R$ 29,99
            R$2.03km
            X
            k
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "com.app99.driver")

        assertEquals("99-card-template", result.parserName)
        assertEquals("Av. Afons de Sampaio e so", result.fields.pickup)
        assertEquals("Av. Aricanduva", result.fields.destination)
        assertEquals("R$ 29,99", result.fields.fare)
    }

    @Test
    fun parsesUberCardUsingPackage() {
        val text = """
            UberX
            Exclusivo
            R$ 29,65
            4 min (1.3 km)
            Rua Paulo Laurito, Sao Mateus, Sao
            Paulo
            47 minutos (16.9 km)
            rua icem, 57, Tatuape, Sao Paulo
            Viagem longa (mais de 45 min)
            Aceitar
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "com.ubercab.driver")

        assertEquals("uber-trip-card", result.parserName)
        assertEquals("Rua Paulo Laurito, Sao Mateus, Sao Paulo", result.fields.pickup)
        assertEquals("rua icem, 57, Tatuape, Sao Paulo", result.fields.destination)
        assertEquals("R$ 29,65", result.fields.fare)
    }

    @Test
    fun parsesInDriveOrderCardUsingPackageAndIgnoresFareActions() {
        val text = """
            Pedido de viagem
            R$ 1,6/km ~3,7 km
            R$ 29
            A Rua Baltazar Vidal 95 (Jardim Nossa Sra. do Carmo)
            B Rua Coelho Lisboa, 419 (Cidade Mae do Ceu, Sao Paulo - SP)
            PIX
            Aceitar por R$ 29
            Ofereca sua tarifa
            R$ 32
            R$ 34
            Fechar
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "sinet.startup.inDriver")

        assertEquals("indrive-order-card", result.parserName)
        assertEquals("Rua Baltazar Vidal 95 (Jardim Nossa Sra. do Carmo)", result.fields.pickup)
        assertEquals("Rua Coelho Lisboa, 419 (Cidade Mae do Ceu, Sao Paulo - SP)", result.fields.destination)
        assertEquals("R$ 29", result.fields.fare)
    }

    @Test
    fun parsesInDriveDiagnosticWithLooseAddressesBeforeMapOcr() {
        val text = """
            Pedido de viagem
            Sarah
            5.0
            (119)
            11 min.
            R$ 2,2/km
            ~1,7 km
            R$ 15
            Rua Gaspar Guterres 129 (Jardim Nossa Sra. do Carmo)
            Rua Rodrigues Seixas, 341 (Cidade Lider, Sao Paulo - SP)
            Rua Rafael Fernandes, 63 (Cidade Lider, Sao Paulo - SP)
            Aceitar por R$ 15
            Ofereca sua tarifa
            R$ 17
            R$ 18
            R$ 20
            R$ 21
            Fechar
            Pedido de viagem
            R$ 15
            1,7 km
            A Rua Gaspar Guterres 129 (Jardim Nossa Sra. do Carmo)
            B Rua Rafael Fernandes, 63
            Aceitar por R$ 15
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "sinet.startup.inDriver")

        assertEquals("indrive-order-card", result.parserName)
        assertEquals("Rua Gaspar Guterres 129 (Jardim Nossa Sra. do Carmo)", result.fields.pickup)
        assertEquals("Rua Rafael Fernandes, 63 (Cidade Lider, Sao Paulo - SP)", result.fields.destination)
        assertEquals("R$ 15", result.fields.fare)
    }

    @Test
    fun parsesFirstInDriveOfferWhenFeedContainsSeveralOrders() {
        val text = """
            Nova notificação
            Resolva esses problemas para evitar perder as melhores solicitações
            Amanda Xavier
            4.85
            (3)
            58 seg.
            R$ 1,6/km
            ~2,4 km
            R$ 15
            Rua Guilherme da Cruz, 16 (Jardim Helian, São Paulo - SP)
            Rua Sabiá da Praia, 191 (Colônia (Zona Leste), São Paulo - SP)
            PIX
            Reclamar
            Ocultar
            Escolher no mapa
            Leandro
            4.84
            (1474)
            10 min.
            R$ 2/km
            ~3,3 km
            R$ 11
            Preço justo
            Rua Isidoro de Lara 265 (Itaquera)
            Rua Águas de Março, 49 (Conjunto Residencial José Bonifácio, São Paulo - SP)
            Pedido de viagem
            R$ 15
            A Rua Guilherme da Cruz, 16
            B Rua Sabiá da Praia, 191 (Colônia (Zona Leste), São Paulo - SP)
            Aceitar por R$ 15
        """.trimIndent()

        val result = RideTextParser().parseWithMetadata(text, "sinet.startup.inDriver")

        assertEquals("indrive-order-card", result.parserName)
        assertEquals("Rua Guilherme da Cruz, 16 (Jardim Helian, São Paulo - SP)", result.fields.pickup)
        assertEquals("Rua Sabiá da Praia, 191 (Colônia (Zona Leste), São Paulo - SP)", result.fields.destination)
        assertEquals("R$ 15", result.fields.fare)
    }
}
